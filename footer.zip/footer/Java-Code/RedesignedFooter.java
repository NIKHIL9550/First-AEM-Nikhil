package com.aem.geeks.core.models;


import java.util.List;
import java.util.Map;

public interface RedesignedFooter {
	public String getLogoImage();
	public String getDescription();
	public String getButtonText();
	public List<Map<String , String>> getAboutLinks();
	public String getSupportMainLink();
	public String getSupportLinkUrl();
	public List<Map<String , String>> getSupportLinks();
	public String getPortalMainLink();
	public String getPortalLinkUrl();
	public List<Map<String , String>> getPortalLinks();
	public String getContactMainLink();
	public String getContactLinkUrl();
	public List<Map<String , String>> getContactLinks();
}
