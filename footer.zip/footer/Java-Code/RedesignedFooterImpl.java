package com.aem.geeks.core.models.impl;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.api.resource.Resource;

import javax.inject.Inject;
import java.util.*;

import com.aem.geeks.core.models.RedesignedFooter;

@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = RedesignedFooter.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class RedesignedFooterImpl implements RedesignedFooter {
	
	@Inject
    Resource componentResource;
	
	@ValueMapValue
    private String companyDescription;
	
	@ValueMapValue
    private String buttonText;
	
	@ValueMapValue
    private String logoImage;

    @ValueMapValue
    private List<String> aboutLinkText;

    @ValueMapValue
    private List<String> aboutSubLinkUrl;
    
    @ValueMapValue
    private String supportMainLink;

    @ValueMapValue
    private String supportLinkUrl;

    @ValueMapValue
    private List<String> supportLinkText;

    @ValueMapValue
    private List<String> supportSubLinkUrl;
    
    @ValueMapValue
    private String portalMainLink;

    @ValueMapValue
    private String portalLinkUrl;

    @ValueMapValue
    private List<String> portalLinkText;

    @ValueMapValue
    private List<String> portalSubLinkUrl;
    
    @ValueMapValue
    private String contactMainLink;

    @ValueMapValue
    private String contactLinkUrl;

    @ValueMapValue
    private List<String> contactLinkText;

    @ValueMapValue
    private List<String> contactSubLinkUrl;
    
    @ValueMapValue

	@Override
	public String getDescription() {
		return companyDescription;
	}

	@Override
	public String getButtonText() {
		return buttonText;
	}
	
	@Override
	public String getLogoImage() {
		return logoImage;
	}
	
	@Override
	public List<Map<String, String>> getAboutLinks() {
		if(aboutLinkText != null) {
			List<Map<String,String>> about = new ArrayList<>();
			for(int i = 0; i < aboutLinkText.size(); i++) {
				Map<String,String> result = new HashMap<>();
				result.put("linkText", aboutLinkText.get(i));
				result.put("linkUrl", aboutSubLinkUrl.get(i));
				about.add(result);
			}
			return about;
		}else {
			return Collections.emptyList();
		}
	}

	@Override
	public String getSupportMainLink() {
		return supportMainLink;
	}

	@Override
	public String getSupportLinkUrl() {
		return supportLinkUrl;
	}

	@Override
	public List<Map<String, String>> getSupportLinks() {
		if(supportLinkText != null ) {
			List<Map<String,String>> support = new ArrayList<>();
			for(int i = 0; i < supportLinkText.size(); i++) {
				Map<String,String> result = new HashMap<>();
				result.put("linkText", supportLinkText.get(i));
				result.put("linkUrl", supportSubLinkUrl.get(i));
				support.add(result);
			}
			return support;
		}else {
			return Collections.emptyList();
		}
	}

	@Override
	public String getPortalMainLink() {
		return portalMainLink;
	}

	@Override
	public String getPortalLinkUrl() {
		return portalLinkUrl;
	}

	@Override
	public List<Map<String, String>> getPortalLinks() {
		if(portalLinkText != null) {
			List<Map<String,String>> portal = new ArrayList<>();
			for(int i = 0; i < portalLinkText.size(); i++) {
				Map<String,String> result = new HashMap<>();
				result.put("linkText", portalLinkText.get(i));
				result.put("linkUrl", portalSubLinkUrl.get(i));
				portal.add(result);
			}
			return portal;
		}else {
			
			return Collections.emptyList();
		}
	}

	@Override
	public String getContactMainLink() {
		return contactMainLink;
	}

	@Override
	public String getContactLinkUrl() {
		return contactLinkUrl;
	}

	@Override
	public List<Map<String, String>> getContactLinks() {
		if(contactLinkText != null) {
			List<Map<String,String>> contact = new ArrayList<>();
			for(int i = 0; i < contactLinkText.size(); i++) {
				Map<String,String> result = new HashMap<>();
				result.put("linkText", contactLinkText.get(i));
				result.put("linkUrl", contactSubLinkUrl.get(i));
				contact.add(result);
			}
			return contact;
		}else {
			return Collections.emptyList();
		}
	}
}
