(function ($) {
  "use strict";

  var dialogContentSelector = ".cmp-teaser__editor";
  var CheckboxTextfieldTuple =
    window.CQ.CoreComponents.CheckboxTextfieldTuple.v1;
  var isDecorative;
  var altTuple;
  var $altGroup;
  var coralTag;
  var fileReference;

  $(document).on("dialog-loaded", function (e) {
    var $dialog = e.dialog;
    var $dialogContent = $dialog.find(dialogContentSelector);
    var dialogContent =
      $dialogContent.length > 0 ? $dialogContent[0] : undefined;
    if (dialogContent) {
      isDecorative = dialogContent.querySelector(
        'coral-checkbox[name="./isDecorative"]'
      );
      altTuple = new CheckboxTextfieldTuple(
        dialogContent,
        'coral-checkbox[name="./altValueFromDAM"]',
        'input[name="./alt"]'
      );
      $altGroup = $dialogContent.find(".cmp-teaser__editor-alt");
      coralTag = dialogContent.querySelector(
        'coral-taglist[name="./imagePath"] coral-tag'
      );
      fileReference = coralTag ? coralTag.value : undefined;
      if (fileReference) {
        retrieveDAMInfo(fileReference).then(function () {
          if (isDecorative) {
            altTuple.hideCheckbox(isDecorative.checked);
          }
          altTuple.reinitCheckbox();
          toggleAlternativeFieldsAndLink(isDecorative);
        });
      }
      toggleAlternativeFieldsAndLink(isDecorative);
    }
  });

  $(window).on("focus", function () {
    if (fileReference) {
      retrieveDAMInfo(fileReference);
    }
  });

  $(document).on("dialog-beforeclose", function () {
    $(window).off("focus");
  });

  $(document).on(
    "change",
    dialogContentSelector + ' coral-checkbox[name="./isDecorative"]',
    function (e) {
      toggleAlternativeFieldsAndLink(e.target);
    }
  );

  $(document).on(
    "change",
    dialogContentSelector + " .image-path",
    function (e) {
      var fileReference = $(e.target).val();
      if (fileReference) {
        retrieveDAMInfo(fileReference).then(function () {
          if (isDecorative) {
            altTuple.hideCheckbox(isDecorative.checked);
          }
          altTuple.reinitCheckbox();
          toggleAlternativeFieldsAndLink(isDecorative);
        });
      }
    }
  );

  function toggleAlternativeFieldsAndLink(checkbox) {
    if (checkbox) {
      if (checkbox.checked) {
        $altGroup.hide();
      } else {
        $altGroup.show();
      }
      altTuple.hideTextfield(checkbox.checked);
      if (fileReference) {
        altTuple.hideCheckbox(checkbox.checked);
      }
    }
  }

  function retrieveDAMInfo(fileReference) {
    return $.ajax({
      url: fileReference + "/_jcr_content/metadata.json",
    }).done(function (data) {
      if (data) {
        if (altTuple) {
          var description = data["dc:description"];
          if (description === undefined || description.trim() === "") {
            description = data["dc:title"];
          }
          altTuple.seedTextValue(description);
          altTuple.update();
          toggleAlternativeFieldsAndLink(isDecorative);
        }
      }
    });
  }

  /* disable required alt field when switching to other type than image */
  $(document).on(
    "change",
    dialogContentSelector + " .cq-dialog-dropdown-showhide",
    function (e) {
      if (e.target && altTuple) {
        if (e.target.value == "showImage") {
          altTuple.update();
        } else {
          altTuple._disableTextfield(true);
        }
      }
    }
  );
})(jQuery);
