package com.fsecure.core.components.models;
 

import java.util.List;
import java.util.Map;

public interface RedesignedHeaderModel {
	public List<Map<String , String>> getHeaderLinks();
	
}
