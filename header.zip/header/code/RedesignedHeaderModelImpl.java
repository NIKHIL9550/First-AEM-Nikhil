package com.fsecure.core.components.internal.models.v1;


import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.Default;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.api.resource.Resource;

import javax.inject.Inject;
import java.util.*;



import com.fsecure.core.components.models.RedesignedHeaderModel;

@Model(
        adaptables = SlingHttpServletRequest.class,
        adapters = RedesignedHeaderModel.class,
        defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL
)
public class RedesignedHeaderModelImpl implements RedesignedHeaderModel {
	
	@Inject
    Resource componentResource;
	
	@ValueMapValue
    private List<String> headerLinkText;
	
	@ValueMapValue
    private List<String> headerSubLinkUrl;
	
	

	@Override
	public List<Map<String, String>> getHeaderLinks() {
		
		if(headerLinkText !=null) {
			List<Map<String,String>> header = new ArrayList<>();
			for(int i = 0; i < headerLinkText.size(); i++) {
				Map<String,String> result = new HashMap<>();
				result.put("linkText", headerLinkText.get(i));
				result.put("linkUrl", headerSubLinkUrl.get(i));
				header.add(result);
			}
			return header;
		}else {
			return Collections.emptyList();
		}
	}

	
	
}

